package Mypackage;

public class PojoVehicle{
    private String model;
    private  int man_year;
    private  String color;
    private int  registration;
    private int price;

    private  boolean isRunning=false;

    public  boolean startVehicle() {
        this.isRunning=true;
        return  true;
    }
    public  boolean switchOffVehicle(){
        this.isRunning=false;
        return false;
    }


    public PojoVehicle(){
        model="activa";
        man_year=2020;
        color="blue";
        registration=1234;
        price=40000;
    }
    public  PojoVehicle(String model,String color,int man_year,int registration,int price){
         this.model=model;
         this.color=color;
         this.man_year=man_year;
         this.registration=registration;
         this.price=price;}


         public String getModel()
         {
             return model;
         }
         public String getColor()
         {
             return  color;
         }

    public int getMan_year() {
        return man_year;
    }

    public int getRegistration() {
        return registration;
    }

    public int getPrice() {
        return price;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setMan_year(int man_year) {
        this.man_year = man_year;
    }

    public void setRegistration(int registration) {
        this.registration = registration;
    }
}


