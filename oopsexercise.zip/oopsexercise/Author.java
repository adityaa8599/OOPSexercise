package Mypackage;

public class Author {
    String name;
    String Email;
    char gender;
    public
}
